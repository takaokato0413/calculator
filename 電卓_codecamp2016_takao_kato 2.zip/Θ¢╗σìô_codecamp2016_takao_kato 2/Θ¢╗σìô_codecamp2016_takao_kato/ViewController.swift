//
//  ViewController.swift
//  電卓_codecamp2016_takao_kato
//
//  Created by takao kato on 2017/01/17.
//  Copyright © 2017年 takao kato. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBOutlet weak var sum: UILabel!
    
    
    
     var Number : Int = 0
    var Number2 : Int = 0
    var nextstep : String?
    var oparation: Int = 0
    var push_btn: Int = 0
    var syori: Bool = false
   
    
    func disp(_ num:Int) {
        Number = Number * 10
        Number += num
        sum.text = String(Number)
    }

    
    
    @IBAction func zero(_ sender: UIButton) {
        push_btn = Int((sender.titleLabel!.text)!)!
        disp(push_btn)
        
    }
    
 //  @IBAction func zero(_ sender: UIButton) {
 //    print("pushed \(sender.currentTitle)")
    
 //   if syori{
 //       let zero = sender.currentTitle!
 //       sum.text = sum.text! + zero
 //   } else {
  //      sum.text = sender.currentTitle!
  //      syori = true
  //  }
   //     sum.text = sum.text! + zero!
  //  }
    
    func initCalc() {
        Number = 0
        Number2 = 0
        oparation = 0
        sum.text = "0"
        push_btn = 0
            }

    
    @IBAction func tasu(_ sender: UIButton) {
        sum.text = "0"
        oparation = 1
        Number2 = Number
        Number = 0
    }
    
    @IBAction func hiku(_ sender: UIButton) {
        sum.text = "0"
        oparation = 2
        Number2 = Number
        Number = 0
    }
    
    @IBAction func waru(_ sender: UIButton) {
        sum.text = "0"
        oparation = 3
        Number2 = Number
        Number = 0
    }
    
    @IBAction func kakeru(_ sender: UIButton) {
        sum.text = "0"
        oparation = 4
        Number2 = Number
        Number = 0
    }
    
    @IBAction func clear(_ sender: UIButton) {
         initCalc()
        
    }
    
    
    
    @IBAction func equall(_ sender: UIButton) {
        
        switch(oparation) {
        case 1:
            sum.text = String(Number2 + Number)
            Number = Number2 + Number
        case 2:
            sum.text = String(Number2 - Number)
            Number = Number2 - Number
        case 3:
            sum.text = String(Number2 / Number)
            Number = Number2 / Number
        case 4:
            sum.text = String(Number2 * Number)
            Number = Number2 * Number
        default:
            sum.text = "Error"
            initCalc()
        }

            }
        }





            //       else if sender.currentTitle == "+" {

            //        Number = Number + Number2
            //    } else if sender.currentTitle == "-" {

            //        Number = Number - Number2
             //   }
                

           //     if (sender.currentTitle == "+" || sender.currentTitle == "-") {
           //         nextstep = sender.currentTitle
          //      }
         //   }
            
        //    sum.text = "\(Number)"
        //    syori = false

        //    if (sender.currentTitle == "=") {
        //        Number = 0
        //        nextstep = nil
        //    }
        

     //   func getDisplayInt() -> Int {
    //        if let sumText = sum.text {
    //            return Int(sumText) ?? 0
     //       } else {
     //           return 0
     //       }
      //  }
   // }
    
    
    
    
    



//   @IBAction func clear(_ sender: UIButton) {
//  }

//   @IBAction func syou(_ sender: UIButton) {
//  }
//   @IBAction func seki(_ sender: UIButton) {
//  }
// @IBAction func minus(_ sender: UIButton) {
//   }
//  @IBAction func plus(_ sender: UIButton) {
//   }
//  @IBAction func equall(_ sender: UIButton) {
//  }

  //  @IBAction func one(_ sender: UIButton) {
//        let one = sender.currentTitle
 //       sum.text = sum.text! + one!
 //       print("sum = \(sum)")
 //   }
  //  @IBAction func two(_ sender: UIButton) {
  //      let two = sender.currentTitle
   //     sum.text = sum.text! + two!
   // }
  //  @IBAction func three(_ sender: UIButton) {
   //     let three = sender.currentTitle
    //    sum.text = sum.text! + three!
  //  }
  //  @IBAction func four(_ sender: UIButton) {
   //     let four = sender.currentTitle
   //     sum.text = sum.text! + four!
   // }
   // @IBAction func five(_ sender: UIButton) {
   //     let five = sender.currentTitle
   //     sum.text = sum.text! + five!
   // }
   // @IBAction func six(_ sender: UIButton) {
   // }
    
  //  @IBAction func seven(_ sender: UIButton) {
   // }
   
   // @IBAction func eight(_ sender: UIButton) {
 //   }
    
    
  //  @IBAction func nine(_ sender: UIButton) {

